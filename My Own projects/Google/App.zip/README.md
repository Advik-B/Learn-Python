This app is provided 'as is' and should NOT be used for commercial purpose.
This app is made by Advik. and should not be copied!

instructions:

double click on "install python.exe" (you may not see the '.exe' extension)
IMPORTANT: make shure that "add python to PATH" is ticked
           make shure that the "PIP" is ticked

double click on "install requirements.bat" (you may not see the '.bat' extension)

DONE!

now you can use the python file! ("info.collect.py")